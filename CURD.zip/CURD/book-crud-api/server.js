const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");
const bookRoutes = require("./routes/bookRoutes");

const app = express();
const PORT = 5001;

connectDB();

app.use(cors());
app.use(express.json());
app.use(express.static("public")); // <--- Serve HTML from /public

app.use("/api", bookRoutes);

app.get("/", (req, res) => {
  res.send("📚 Welcome to Book CRUD API");
});

app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
